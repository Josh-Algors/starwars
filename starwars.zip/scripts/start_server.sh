#!/bin/bash
cd /home/ubuntu/starwars/
npm start